package com.hotelalura.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelAluraProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
