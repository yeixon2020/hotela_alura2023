package com.hotelalura.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotelalura.core.model.Pais;

public interface PaisRepository extends JpaRepository<Pais, Integer> {

}
