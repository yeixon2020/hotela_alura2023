package com.hotelalura.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotelalura.core.model.Huesped;

public interface HuespedRepository extends JpaRepository<Huesped, Integer> {

}
